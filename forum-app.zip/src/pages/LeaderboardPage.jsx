import React from 'react';
import Leaderboard from '../features/leaderBoard/components/Leaderboard';

const LeaderboardPage = () => {
  return (
    <div>
      <Leaderboard />
    </div>
  );
};

export default LeaderboardPage;