import React from 'react';
import RegisterForm from '../features/auth/components/RegisterForm';

const RegisterPage = () => {
  return <RegisterForm />;
};

export default RegisterPage;