import React from 'react';
import LoginForm from '../features/auth/components/LoginForm';

const LoginPage = () => {
  return <LoginForm />;
};

export default LoginPage;