import React from 'react';
import ThreadDetail from '../features/threads/components/ThreadDetail';

const ThreadDetailPage = () => {

  return (
    <div>
      <ThreadDetail />
    </div>
  );
};

export default ThreadDetailPage;
