import React from 'react';
import CreateThread from '../features/threads/components/CreateThread';

const CreateThreadPage = () => {
  return (
    <div>
      <CreateThread />
    </div>
  );
};

export default CreateThreadPage;